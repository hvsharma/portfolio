$(function(){
    $("#btn-fb").click(function(){
        window.open("https://www.facebook.com/hvsharma","_blank");
    });

    $("#btn-gh").click(function(){
        window.open("https://www.github.com/hvsharma","_blank");
    });

    $("#btn-lin").click(function(){
        window.open("https://www.linkedin.com/in/sharmahv","_blank");
    });

    $("#btn-ig").click(function(){
        window.open("https://www.instagram.com/sharma_hv","_blank");
    });

    $("#btn-twt").click(function(){
        window.open("https://www.twitter.com/sharma_hv","_blank");
    });   
});